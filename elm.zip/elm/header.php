<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible"
              content="IE=edge">
        <meta name="viewport"
              content="width=device-width, initial-scale=1, shrink-to-fit=no">
              


        <title>ELM + + </title>


        <script src="<?php echo ASSETS; ?>/js/jquery-1.9.1.min.js"></script>
 <link href="<?php echo ASSETS; ?>/jGrowl/jquery.jgrowl.css" rel="stylesheet" media="screen">
 <script src="<?php echo ASSETS; ?>/jGrowl/jquery.jgrowl.js"></script>
   
    
        <!-- Custom Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Oswald:400,500,700%7CRoboto:400,500%7CRoboto:400,500&amp;display=swap"
              rel="stylesheet">

        <!-- Perfect Scrollbar -->
        <link type="text/css"
              href="<?php echo ASSETS; ?>/vendor/perfect-scrollbar.css"
              rel="stylesheet">

        <!-- Material Design Icons -->
        <link type="text/css"
              href="<?php echo ASSETS; ?>/css/material-icons.css"
              rel="stylesheet">

        <!-- Font Awesome Icons -->
        <link type="text/css"
              href="<?php echo ASSETS; ?>/css/fontawesome.css"
              rel="stylesheet">

        <!-- Preloader -->
        <link type="text/css"
              href="<?php echo ASSETS; ?>/vendor/spinkit.css"
              rel="stylesheet">

        <!-- App CSS -->
        <link type="text/css"
              href="<?php echo ASSETS; ?>/css/app.css"
              rel="stylesheet">

    <!-- Touchspin -->
    <link rel="stylesheet"
              href="<?php echo ASSETS; ?>/css/bootstrap-touchspin.css">

        <!-- Vendor CSS -->
        <link rel="stylesheet"
              href="<?php echo ASSETS; ?>/css/nestable.css">
    </head>