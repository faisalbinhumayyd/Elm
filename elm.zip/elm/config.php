<?php 

error_reporting(~E_ALL);
// base url
define("ASSETS","http://localhost/elm/assets");


define("BU","http://localhost/elm/");

?>