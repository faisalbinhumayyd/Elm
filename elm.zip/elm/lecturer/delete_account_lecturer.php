 
									<div class="tab-pane" id="fourth">
										
                                   
                                           
                                            <div class="form-group row">
                                                <div class="col-sm-8 offset-sm-3">
                                                    <div class="media align-items-center">
                                                        <div class="media-left">
														<p > if you press on delete my account, your account will not availibale </p>
														<a href="delete_account_lecturer_form.php" > 
														<button  class="btn btn-danger"  type="submit"><i class="icon-check icon-large"></i> delete my account</button>
														</a>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                            </div>  
                                    </div>
	
									<?php include '../script.php' ?>
			
		