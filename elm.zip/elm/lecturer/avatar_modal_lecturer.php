
<div class="tab-pane" id="second">
<form method="post" action="lecturer_avatar.php" enctype="multipart/form-data"
                                              class="form-horizontal">
                                              <div class="form-group row">
                                                <label for="avatar"  class="col-sm-3 col-form-label form-label">Avatar</label>
													<div class="col-sm-9">
														<div class="media align-items-center">
															<div class="media-left">
																<div class="icon-block rounded">
																	<i class="material-icons text-muted-light md-36">photo</i>
																</div>
															</div>
															<div class="media-body">
																<div class="custom-file"
																	style="width: auto;">
																	<input type="file"
																	id="fileInput"
																		name="image"
																		class="custom-file-input" required> 
																	<label for="avatar"
																		class="custom-file-label">Choose file</label>
																</div>
															</div>

														 </div>
														 <div class="form-group row" style="margin-top:100px">
                                                <div class="col-sm-8 offset-sm-3" >
                                                    <div class="media align-items-center">
                                                        <div class="media-left">
														<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i> Close</button>
														<button class="btn btn-info" name="change"><i class="icon-save icon-large"></i> Save</button>
														
                                                            
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                            </div>
												

                                                </div>
                                            </div>
                                        </form>
                                       
                                    </div>
