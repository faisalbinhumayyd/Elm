
					
								<!-- class delete modal -->
				<div id="course_delete" class="form-group" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				
		
					<div class="form-group">
					<p> Select Courses are you want do delete them !! </p>
						<button name="delete_course" class="btn btn-danger"> <i class="material-icons">delete</i></button>
					</div>
			   </div>
					
					
					
					