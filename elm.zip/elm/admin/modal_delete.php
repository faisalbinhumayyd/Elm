					<!-- user delete modal -->
					<div id="user_delete" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
					<h3 id="myModalLabel">Delete Users?</h3>
					</div>
					<div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the user you check?.</p>
					</div>
					</div>
					<div class="modal-footer">
					<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i> Close</button>
					<button name="delete_user" class="btn btn-danger"><i class="icon-check icon-large"></i> Yes</button>
					</div>
					</div>
					
					<!-- department delete modal -->
					<div id="department_delete" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
					<h3 id="myModalLabel">Delete Department?</h3>
					</div>
					<div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the department you check?.</p>
					</div>
					</div>
					<div class="modal-footer">
					<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i> Close</button>
					<button name="delete_department" class="btn btn-danger"><i class="icon-check icon-large"></i> Yes</button>
					</div>
					</div>
					
								<!-- class delete modal -->
					<div id="class_delete" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
					<h3 id="myModalLabel">Delete Class?</h3>
					</div>
					<div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the class you check?.</p>
					</div>
					</div>
					<div class="modal-footer">
					<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i> Close</button>
					<button name="delete_class" class="btn btn-danger"><i class="icon-check icon-large"></i> Yes</button>
					</div>
					</div>
					
											<!-- student delete modal -->
					<div id="student_delete" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
					<h3 id="myModalLabel">Delete Student?</h3>
					</div>
					<div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the student you check?.</p>
					</div>
					</div>
					<div class="modal-footer">
					<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i> Close</button>
					<button name="delete_student" class="btn btn-danger"><i class="icon-check icon-large"></i> Yes</button>
					</div>
					</div>
					
					
											<!-- student delete modal -->
					<div id="lecturer_delete" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
					<h3 id="myModalLabel">Delete lecturer?</h3>
					</div>
					<div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the lecturer you check?.</p>
					</div>
					</div>
					<div class="modal-footer">
					<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i> Close</button>
					<button name="delete_lecturer" class="btn btn-danger"><i class="icon-check icon-large"></i> Yes</button>
					</div>
					</div>
					
					
					                 	<!-- Content delete modal -->
					<div id="content_delete" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
					<h3 id="myModalLabel">Delete Content?</h3>
					</div>
					<div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the Content you check?.</p>
					</div>
					</div>
					<div class="modal-footer">
					<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i> Close</button>
					<button name="delete_content" class="btn btn-danger"><i class="icon-check icon-large"></i> Yes</button>
					</div>
					</div>
					
					
					



					<!-- Content delete modal -->
					<div id="subject_delete" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
					<h3 id="myModalLabel">Delete Subject?</h3>
					</div>
					<div class="modal-body">
					<div class="alert alert-danger">
					<p>Are you sure you want to delete the subject you check?.</p>
					</div>
					</div>
					<div class="modal-footer">
					<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i> Close</button>
					<button name="delete_subject" class="btn btn-danger"><i class="icon-check icon-large"></i> Yes</button>
					</div>
					</div>










					<div class="modal fade"
             id="editQuiz">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-primary">
                        <h4 class="modal-title text-white">Edit Question</h4>
                        <button type="button"
                                class="close text-white"
                                data-dismiss="modal"
                                aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="#">
                            <div class="form-group row">
                                <label for="qtitle"
                                       class="col-form-label form-label col-md-3">Title:</label>
                                <div class="col-md-9">
                                    <input id="qtitle"
                                           type="text"
                                           class="form-control"
                                           value="Database Access">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="type"
                                       class="col-form-label form-label col-md-3">Type:</label>
                                <div class="col-md-4">
                                    <select id="type"
                                            class="custom-control custom-select form-control">
                                        <option value="1">Input</option>
                                        <option value="2">Textarea</option>
                                        <option value="3">Checkbox</option>
                                        <option value="3">Radio</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-form-label form-label col-md-3">Answers:</label>
                                <div class="col-md-9">
                                    <a href="#"
                                       class="btn btn-default"><i class="material-icons">add</i> Add Answer</a>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="touch-spin-2"
                                       class="col-form-label form-label col-md-3">Question Score:</label>
                                <div class="col-md-4">
                                    <input id="touch-spin-2"
                                           data-toggle="touch-spin"
                                           data-min="0"
                                           data-max="100"
                                           data-step="5"
                                           type="text"
                                           value="50"
                                           name="demo2"
                                           class="form-control" />
                                </div>
                            </div>
                            <div class="form-group row mb-0">
                                <div class="col-md-8 offset-md-3">
                                    <button type="submit"
                                            class="btn btn-success">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>