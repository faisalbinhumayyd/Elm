<div class="mdk-drawer js-mdk-drawer"
                 id="default-drawer">
                <div class="mdk-drawer__content ">
                    <div class="sidebar sidebar-left sidebar-dark bg-dark o-hidden"
                         data-perfect-scrollbar>
                        <div class="sidebar-p-y">

                            <!-- Account menu -->

                            <div class="sidebar-heading">user</div>
                            <ul class="sidebar-menu sm-active-button-bg">
                              
                                <li class="sidebar-menu-item">
                                    <a class="sidebar-menu-button"
                                       href="course.php">
                                        <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">import_contacts</i> View Course
                                    </a>
                                </li>
                             
                            
                                <li class="sidebar-menu-item">
                                    <a class="sidebar-menu-button"
                                       href="lecturer.php">
                                        <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">school</i> Lecturer
                                    </a>
                                </li>
                                <li class="sidebar-menu-item">
                                    <a class="sidebar-menu-button"
                                       href="students.php">
                                        <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">account_box</i> Student
                                    </a>
                                </li>

                            
                                <li class="sidebar-menu-item">
                                    <a class="sidebar-menu-button"
                                       href="stats.php">
                                       
                                        <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">stacked_bar_chart</i> Statistics
                                    </a>
                                </li>
                                
                                <li class="sidebar-menu-item">
                                    <a class="sidebar-menu-button"
                                       href="logout.php">
                                        <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">lock_open</i> Logout
                                    </a>
                                </li>
                            </ul>


                        </div>
                    </div>
                </div>
            </div>