  


<!-- jQuery 
<script src="<?php echo ASSETS; ?>/vendor/jquery.min.js"></script>-->

<!-- Bootstrap -->
<script src="<?php echo ASSETS; ?>/vendor/popper.min.js"></script>
<script src="<?php echo ASSETS; ?>/vendor/bootstrap.min.js"></script>

<!-- Perfect Scrollbar -->
<script src="<?php echo ASSETS; ?>/vendor/perfect-scrollbar.min.js"></script>


<!-- MDK -->
<script src="<?php echo ASSETS; ?>/vendor/dom-factory.js"></script>
<script src="<?php echo ASSETS; ?>/vendor/material-design-kit.js"></script>

<!-- App JS -->
<script src="<?php echo ASSETS; ?>/js/app.js"></script>

<!-- Highlight.js -->
<script src="<?php echo ASSETS; ?>/js/hljs.js"></script>

<!-- App Settings (safe to remove) -->
<script src="<?php echo ASSETS; ?>/js/app-settings.js"></script>

        <!-- Global Settings -->
        <script src="<?php echo ASSETS; ?>/js/settings.js"></script>


     <!-- Moment.js -->
     <script src="<?php echo ASSETS; ?>/vendor/moment.min.js"></script>
        <script src="<?php echo ASSETS; ?>/vendor/moment-range.js"></script> 

        <!-- Chart.js -->
        <script src="<?php echo ASSETS; ?>/vendor/Chart.min.js"></script>
        <script src="<?php echo ASSETS; ?>/js/chartjs-rounded-bar.js"></script>
        <script src="<?php echo ASSETS; ?>/js/chartjs.js"></script>

        <!-- Student Dashboard Page JS -->
        <!-- <script src="assets/js/chartjs-rounded-bar.js"></script> -->
        <script src="<?php echo ASSETS; ?>/js/page.student-dashboard.js"></script>
        <!-- Instructor Dashboard Page JS -->
        <script src="<?php echo ASSETS; ?>/js/page.instructor-dashboard.js"></script>

         <!-- List.js -->
         <script src="<?php echo ASSETS; ?>/vendor/list.min.js"></script>
        <script src="<?php echo ASSETS; ?>/js/list.js"></script>
           <!-- Vendor JS -->
           <script src="<?php echo ASSETS; ?>/vendor/jquery.nestable.js"></script>
        <script src="<?php echo ASSETS; ?>/vendor/jquery.bootstrap-touchspin.js"></script>

        <!-- Initialize -->
        <script src="<?php echo ASSETS; ?>/js/nestable.js"></script>
        <script src="<?php echo ASSETS; ?>/js/touchspin.js"></script>





 <link href="<?php echo ASSETS; ?>/jGrowl/jquery.jgrowl.css" rel="stylesheet" media="screen">
 <script src="<?php echo ASSETS; ?>/jGrowl/jquery.jgrowl.js"></script>