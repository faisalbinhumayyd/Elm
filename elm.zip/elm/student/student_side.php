<div class="mdk-drawer js-mdk-drawer"
                 id="default-drawer">
                <div class="mdk-drawer__content ">
                    <div class="sidebar sidebar-left sidebar-dark bg-dark o-hidden"
                         data-perfect-scrollbar>
                        <div class="sidebar-p-y">

                            <!-- Account menu -->

                            <div class="sidebar-heading">Student</div>
                            <ul class="sidebar-menu sm-active-button-bg">

                            <li class="sidebar-menu-item">
                                    <a class="sidebar-menu-button"
                                       href="student-dashboard.php">
                                        <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">home</i> Home
                                    </a>
                                </li>
                            
                               
                            
                                <li class="sidebar-menu-item">
                                    <a class="sidebar-menu-button"
                                       href="student-quiz-results.php">
                                        <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">poll</i> Quiz Results
                                    </a>
                                </li>
                                <li class="sidebar-menu-item">
                                    <a class="sidebar-menu-button"
                                       href="student-my-courses.php">
                                        <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">school</i> My Courses  
                                    </a>
                                </li>
                                <li class="sidebar-menu-item">
                                    <a class="sidebar-menu-button"
                                       href="plans.php">
                                        <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">monetization_on </i> Plans  
                                    </a>
                                </li>

                            
                                <li class="sidebar-menu-item">
                                    <a class="sidebar-menu-button"
                                       href="../logout.php">
                                        <i class="sidebar-menu-icon sidebar-menu-icon--left material-icons">lock_open</i> Logout
                                    </a>
                                </li>
                            </ul>


                        </div>
                    </div>
                </div>
            </div>