<?php
namespace Phppot;

class Config
{

    // Possible values: star | favourite | emoji
    const RATING_APPEARANCE = "favourite";
}   