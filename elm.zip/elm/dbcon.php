<?php
$conn = mysqli_connect('localhost','root','A7mdsayed','elm') or die(mysqli_error('connexion error'));
?>